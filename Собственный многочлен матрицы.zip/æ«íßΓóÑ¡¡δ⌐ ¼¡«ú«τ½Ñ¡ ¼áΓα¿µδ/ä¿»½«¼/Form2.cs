﻿/*
 * The proper polynomial of the matrix
 * This software is designed to calculate the proper polynomial of the input matrix.
 * Copyright (C) 2018 Telesheva Tatyana
 * E-mail: teleshevati@mail.ru
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;


namespace Диплом
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private void справкаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("Справка.chm");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Levere F3;
            Hide();
            F3 = new Levere();
            F3.Show();
            F3.FormClosed += Close;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Fadeev F4;
            Hide();
            F4 = new Fadeev();
            F4.Show();
            F4.FormClosed += Close;
        }
        void Close(object sender, System.Windows.Forms.FormClosedEventArgs e)
        { 
            this.Close(); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Krylov F5;
            Hide();
            F5 = new Krylov();
            F5.Show();
            F5.FormClosed += Close;
        }
        private void button1_MouseEnter(object sender, EventArgs e)
        {
            this.button1.ForeColor = Color.FromArgb(13, 93, 170);
            this.button1.BackColor = Color.FromName("White");
        }
        private void button1_MouseLeave(object sender, EventArgs e)
        {
            this.button1.ForeColor = Color.FromName("White");
            this.button1.BackColor = Color.FromArgb(13, 93, 170);
        }
        private void button2_MouseEnter(object sender, EventArgs e)
        {
            this.button2.ForeColor = Color.FromArgb(13, 93, 170);
            this.button2.BackColor = Color.FromName("White");
        }
        private void button2_MouseLeave(object sender, EventArgs e)
        {
            this.button2.ForeColor = Color.FromName("White");
            this.button2.BackColor = Color.FromArgb(13, 93, 170);
        }
        private void button3_MouseEnter(object sender, EventArgs e)
        {
            this.button3.ForeColor = Color.FromArgb(13, 93, 170);
            this.button3.BackColor = Color.FromName("White");
        }
        private void button3_MouseLeave(object sender, EventArgs e)
        {
            this.button3.ForeColor = Color.FromName("White");
            this.button3.BackColor = Color.FromArgb(13, 93, 170);
        }
    }
}
