﻿/*
 * The proper polynomial of the matrix
 * This software is designed to calculate the proper polynomial of the input matrix.
 * Copyright (C) 2018 Telesheva Tatyana
 * E-mail: teleshevati@mail.ru
 * 
 * This program is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace Диплом
{
    public partial class Levere : Form
    {
        public Levere()
        {
            InitializeComponent();
        }
        private void главноеМенюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 F2;
            Hide();
            F2 = new Form2();
            F2.Show();
            F2.FormClosed += Close;
        }
        private void справкаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("Справка.chm");
        }
        void Close(object sender, System.Windows.Forms.FormClosedEventArgs e)
        { 
            this.Close(); 
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                string Text;
                bool a = true;
                Text = textBox1.Text;
                string[] X;
                X = Text.Split(new char[] { });
                for (int i = 0; i < X[0].Length; i++)
                    if (X[0][i] < '0' || X[0][i] > '9')
                        a = false;
                if (a == false)
                {
                    MessageBox.Show("Введённая размерность не является целым числом", "Ошибка ввода данных");
                    this.button1.Visible = false;
                    this.textBox1.Text = "";
                }
                else
                {
                    int text;
                    text = Convert.ToInt32(textBox1.Text);
                    this.textBox2.Text = Convert.ToString(text);
                    this.button1.Visible = true;
                }
                this.button2.Visible = false;
            }
            else
            {
                textBox2.Clear();
                this.button1.Visible = false;
                this.button2.Visible = false;
            }
        }
        int n;
        private void button1_Click(object sender, EventArgs e)
        {
            n = Convert.ToInt32(textBox1.Text);
            this.dataGridView1.Visible = true;
            dataGridView1.Columns.Clear();
            dataGridView1.ColumnCount = n;
            dataGridView1.RowCount = n;
            if (n < 10)
            {
                for (int i = 0; i < n; i++)
                    this.dataGridView1.Columns[i].Width = (300 - 4) / n;
                for (int i = 0; i < n; i++)
                    this.dataGridView1.Rows[i].Height = (280 - 4) / n;
            }
            else
            {
                for (int i = 0; i < n; i++)
                    this.dataGridView1.Columns[i].Width = 29;
                for (int i = 0; i < n; i++)
                    this.dataGridView1.Rows[i].Height = 27;
            }
            this.button2.Visible = true;
            this.textBox3.Visible = false;
            this.label3.Visible = false;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            n = Convert.ToInt32(textBox1.Text);
            string[,] Text = new string[n, n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    Text[i, j] = Convert.ToString(this.dataGridView1.Rows[i].Cells[j].Value);
            int a = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    if (Text[i, j] != "")
                    {
                        string[] X;
                        X = Text[i, j].Split(new char[] { });
                        if (X[0][0] == ',') a = 2;//введеное значение не является числом
                        else
                        {
                            if (X[0][0] == '-')
                            {
                                for (int k = 1; k < X[0].Length; k++)
                                    if ((X[0][k] < '0' || X[0][k] > '9') ^ (X[0][k] == ',' && k > 0))
                                        a = 2;//введеное значение не является числом
                            }
                            else
                            {
                                for (int k = 0; k < X[0].Length; k++)
                                    if ((X[0][k] < '0' || X[0][k] > '9') ^ (X[0][k] == ',' && k > 0))
                                        a = 2;//введеное значение не является числом
                            }
                        }
                    }
                    else a = 1;//пустая ячейка
                }
            if (a == 0)
            {
                double[,] IsxodMass = new double[n + 1, n + 1];
                double[,] EdinicaMass = new double[n + 1, n + 1];
                double[,] YmnojMass = new double[n + 1, n + 1];
                double[] SumGlavDiag = new double[n + 1];
                double[] Polinom = new double[n + 1];
                for (int i = 1; i <= n; i++)
                    for (int j = 1; j <= n; j++)
                    {
                        IsxodMass[i, j] = Convert.ToDouble(this.dataGridView1.Rows[i - 1].Cells[j - 1].Value);
                    }
                for (int i = 1; i <= n; i++)
                {
                    SumGlavDiag[i] = 0;
                    for (int j = 1; j <= n; j++)
                    {
                        YmnojMass[i, j] = 0;
                    }
                }
                for (int i = 1; i <= n; i++)
                    for (int j = 1; j <= n; j++)
                        if (i == j) EdinicaMass[i, i] = 1; else EdinicaMass[i, j] = 0;
                for (int k = 1; k <= n; k++)
                {
                    for (int i = 1; i <= n; i++)
                        for (int j = 1; j <= n; j++)
                            for (int l = 1; l <= n; l++)
                            {
                                YmnojMass[i, j] = YmnojMass[i, j] + IsxodMass[i, l] * EdinicaMass[l, j]; //умножение матриц
                            }
                    for (int i = 1; i <= n; i++)
                        for (int j = 1; j <= n; j++)
                            if (i == j) SumGlavDiag[k] = SumGlavDiag[k] + YmnojMass[i, j];
                    for (int i = 1; i <= n; i++)
                        for (int j = 1; j <= n; j++)
                            EdinicaMass[i, j] = YmnojMass[i, j];
                    for (int i = 1; i <= n; i++)
                        for (int j = 1; j <= n; j++)
                            YmnojMass[i, j] = 0;
                }
                for (int k = 1; k <= n; k++)
                    Polinom[k] = 0;
                SumGlavDiag[0] = 0;
                double t = 0;
                int r = 1;
                for (int k = 1; k <= n; k++)
                {
                    for (int m = k - 1; m > 0; m--)
                    {
                        t = t + Polinom[r] * SumGlavDiag[m]; r++;
                    }
                    Polinom[k] = -((SumGlavDiag[k] + t) / k);
                    t = 0; r = 1;
                }
                this.textBox3.Visible = true;
                this.label3.Visible = true;
                string V = "det⁡(A - λE) = ";
                int W = n;
                for (int i = 1; i <= n; i++)
                {
                    if (Polinom[i] < 0)
                    {
                        if (i != n)
                            V = V + "λ^" + W + " - " + Polinom[i] * (-1) + "*";
                        else V = V + "λ^" + W + " - " + Polinom[i] * (-1);
                    }
                    else
                    {
                        if (i != n)
                            V = V + "λ^" + W + " + " + Polinom[i] + "*";
                        else V = V + "λ^" + W + " + " + Polinom[i];
                    }
                    W--;
                }
                this.textBox3.Clear();
                this.textBox3.Text = V;
            }
            else 
            {
                if(a == 1) MessageBox.Show("Заполните все ячейки числами", "Пустые ячейки");
                else if (a == 2) MessageBox.Show("Введено неправильное число\n\r(Пример записи вещественного числа: 13,5)", "Ошибка ввода элементов матрицы");
            }
        }
        private void button1_MouseEnter(object sender, EventArgs e)
        {
            this.button1.ForeColor = Color.FromArgb(13, 93, 170);
            this.button1.BackColor = Color.FromName("White");
        }
        private void button1_MouseLeave(object sender, EventArgs e)
        {
            this.button1.ForeColor = Color.FromName("White");
            this.button1.BackColor = Color.FromArgb(13, 93, 170);
        }
        private void button2_MouseEnter(object sender, EventArgs e)
        {
            this.button2.ForeColor = Color.FromArgb(13, 93, 170);
            this.button2.BackColor = Color.FromName("White");
        }
        private void button2_MouseLeave(object sender, EventArgs e)
        {
            this.button2.ForeColor = Color.FromName("White");
            this.button2.BackColor = Color.FromArgb(13, 93, 170);
        }
    }
}
